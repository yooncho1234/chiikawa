"""Encode the transparent sprite atlas into Windows premultiplied BGRA resources.
Requires Pillow only for rebuilding; the finished EXE has no Python dependency.
"""
from pathlib import Path
from PIL import Image
import numpy as np
root=Path(__file__).resolve().parent
atlas=Image.open(root/'sprites.png').convert('RGBA')
assert atlas.getextrema()[3][0]==0, 'Atlas must have real transparency'
for i in range(3):
 tile=atlas.crop((round(i*atlas.width/3),0,round((i+1)*atlas.width/3),atlas.height))
 tile=tile.crop(tile.getbbox())
 tile.thumbnail((280,300),Image.Resampling.LANCZOS)
 canvas=Image.new('RGBA',(320,366))
 canvas.alpha_composite(tile,((320-tile.width)//2,350-tile.height))
 a=np.array(canvas,dtype=np.uint16)
 a[:,:,:3]=(a[:,:,:3]*a[:,:,3:4]+127)//255
 (root/f'state{i}.bgra').write_bytes(a[:,:,[2,1,0,3]].astype('uint8').tobytes())
 if i==0:canvas.save(root/'pet.ico',sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])
print('Encoded 3 alpha sprites.')

# Encode the generated 4x2 animation atlas for the transparent mode.
atlas=Image.open(root/'animation.png').convert('RGBA')
for i in range(8):
 x,y=i%4,i//4
 tile=atlas.crop((x*atlas.width//4,y*atlas.height//2,(x+1)*atlas.width//4,(y+1)*atlas.height//2))
 tile=tile.crop(tile.getbbox());tile.thumbnail((280,300),Image.Resampling.LANCZOS)
 canvas=Image.new('RGBA',(320,366));canvas.alpha_composite(tile,((320-tile.width)//2,350-tile.height))
 a=np.array(canvas,dtype=np.uint16);a[:,:,:3]=(a[:,:,:3]*a[:,:,3:4]+127)//255
 (root/f'anim{i}.bgra').write_bytes(a[:,:,[2,1,0,3]].astype('uint8').tobytes())
 if i==0:canvas.save(root/'pet.ico',sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])

# Convert background-removed storyboard poses into timed transparent clips.
# Original GIFs remain intact in originals/. Frames are AI reconstructed from
# 12 sampled poses; timings accumulate the original durations between samples.
import struct,json
meta=json.loads((root/'cutouts'/'timing.json').read_text())
for name in ['turn','walk','desk']:
 atlas=Image.open(root/'cutouts'/f'{name}.png').convert('RGBA')
 tiles=[]
 for i in range(12):
  x,y=i%4,i//4
  tiles.append(atlas.crop((x*atlas.width//4,y*atlas.height//3,(x+1)*atlas.width//4,(y+1)*atlas.height//3)))
 # Use one common crop and scale for the whole clip to avoid size pumping.
 boxes=[im.getbbox() for im in tiles];boxes=[b for b in boxes if b]
 box=(min(b[0] for b in boxes),min(b[1] for b in boxes),max(b[2] for b in boxes),max(b[3] for b in boxes))
 frames=[]
 for tile in tiles:
  tile=tile.crop(box);tile.thumbnail((280,300),Image.Resampling.LANCZOS)
  canvas=Image.new('RGBA',(320,366));canvas.alpha_composite(tile,((320-tile.width)//2,350-tile.height))
  a=np.array(canvas,dtype=np.uint16);a[:,:,:3]=(a[:,:,:3]*a[:,:,3:4]+127)//255
  frames.append(a[:,:,[2,1,0,3]].astype('uint8').tobytes())
 durations=meta[name]
 payload=struct.pack('<I',len(frames))+struct.pack('<'+'I'*len(frames),*durations)+b''.join(frames)
 (root/f'{name}.clip').write_bytes(payload)
 print(name,len(frames),'transparent poses',sum(durations),'ms')
