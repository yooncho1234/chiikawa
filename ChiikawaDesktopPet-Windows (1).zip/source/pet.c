#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <math.h>
#include <stdlib.h>
#include "animation.h"

#define TRAY (WM_APP+1)
#define KEY RGB(255,0,255)
static int scene=0;static ULONGLONG sceneStart;
static HWND win; static NOTIFYICONDATAW tray; static int tick, mood, moodUntil, dir=1,sz=210; static BOOL roam=TRUE,sleeping=FALSE,drag=FALSE,top=TRUE; static POINT anchor,origin; static int travel=0;
static void paint(HDC unused){
 (void)unused;
 const int W=320,H=366;
 HDC screen=GetDC(NULL),src=CreateCompatibleDC(screen),dst=CreateCompatibleDC(screen);
 BITMAPINFO bi={0};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);bi.bmiHeader.biWidth=W;bi.bmiHeader.biHeight=-H;bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
 void *pixels;HBITMAP sb=CreateDIBSection(screen,&bi,DIB_RGB_COLORS,&pixels,NULL,0);HGDIOBJ so=SelectObject(src,sb);
 int resource=scene?300+scene:pet_frame((unsigned)tick,mood,sleeping,roam,drag);
 HRSRC res=FindResourceW(NULL,MAKEINTRESOURCEW(resource),RT_RCDATA);HGLOBAL loaded=LoadResource(NULL,res);const unsigned char *data=(const unsigned char*)LockResource(loaded);
 if(scene){const DWORD *meta=(const DWORD*)data;DWORD n=meta[0],total=0;for(DWORD i=0;i<n;i++)total+=meta[i+1];DWORD phase=(DWORD)((GetTickCount64()-sceneStart)%total),frame=0;while(frame+1<n&&phase>=meta[frame+1]){phase-=meta[frame+1];frame++;}data+=4*(n+1)+(size_t)frame*W*H*4;}
 memcpy(pixels,data,W*H*4);
 if(sleeping){HFONT f=CreateFontW(-25,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,ANTIALIASED_QUALITY,0,L"Segoe UI");HGDIOBJ oldfont=SelectObject(src,f);SetBkMode(src,TRANSPARENT);SetTextColor(src,RGB(100,89,115));RECT txt={230,6,319,45};DrawTextW(src,L"z Z",-1,&txt,DT_CENTER);SelectObject(src,oldfont);DeleteObject(f);unsigned char *p=(unsigned char*)pixels;for(int y=0;y<46;y++)for(int x=0;x<W;x++){int j=(y*W+x)*4;if(p[j]||p[j+1]||p[j+2])p[j+3]=255;}}
 // Overlay a small heart above the original character on a click.
 if(mood==1){unsigned char *p=(unsigned char*)pixels;for(int y=9;y<46;y++)for(int x=137;x<183;x++){double X=(x-160)/19.0,Y=-(y-29)/17.0;double q=X*X+Y*Y-1;if(q*q*q-X*X*Y*Y*Y<=0){int i=(y*W+x)*4;p[i]=150;p[i+1]=119;p[i+2]=239;p[i+3]=255;}}}
 int height=sz*H/W;bi.bmiHeader.biWidth=sz;bi.bmiHeader.biHeight=-height;void *out;HBITMAP db=CreateDIBSection(screen,&bi,DIB_RGB_COLORS,&out,NULL,0);HGDIOBJ old=SelectObject(dst,db);memset(out,0,sz*height*4);
 int bob=(sleeping||scene)?0:(int)(sin(tick*.17)*sz*.012);BLENDFUNCTION blend={AC_SRC_OVER,0,255,AC_SRC_ALPHA};AlphaBlend(dst,0,bob,sz,height-6,src,0,0,W,H,blend);
 RECT r;GetWindowRect(win,&r);POINT at={r.left,r.top},zero={0,0};SIZE size={sz,height};UpdateLayeredWindow(win,screen,&at,&size,dst,&zero,0,&blend,ULW_ALPHA);
 SelectObject(src,so);SelectObject(dst,old);DeleteObject(sb);DeleteObject(db);DeleteDC(src);DeleteDC(dst);ReleaseDC(NULL,screen);
}
static RECT area(void){RECT wr;GetWindowRect(win,&wr);HMONITOR m=MonitorFromRect(&wr,MONITOR_DEFAULTTONEAREST);MONITORINFO mi={0};mi.cbSize=sizeof(mi);GetMonitorInfoW(m,&mi);return mi.rcWork;}
static void clamp(void){RECT a=area(),r;GetWindowRect(win,&r);int w=sz,h=sz*366/320;int x=r.left,y=r.top;if(x<a.left)x=a.left;if(y<a.top)y=a.top;if(x+w>a.right)x=a.right-w;if(y+h>a.bottom)y=a.bottom-h;SetWindowPos(win,top?HWND_TOPMOST:HWND_NOTOPMOST,x,y,w,h,SWP_NOACTIVATE);}
static void menu(void){HMENU m=CreatePopupMenu();AppendMenuW(m,MF_STRING,1,L"간식 주기 🍪");AppendMenuW(m,MF_STRING|(sleeping?MF_CHECKED:0),2,L"잠자기 / 깨우기");AppendMenuW(m,MF_STRING|(roam?MF_CHECKED:0),3,L"자동 산책");AppendMenuW(m,MF_STRING|(top?MF_CHECKED:0),4,L"항상 위에 표시");AppendMenuW(m,MF_SEPARATOR,0,0);AppendMenuW(m,MF_STRING|(!scene?MF_CHECKED:0),10,L"투명 펫 · 눈 뜨기 / 걷기");AppendMenuW(m,MF_STRING|(scene==1?MF_CHECKED:0),11,L"배경 없는 동작 · 뒤돌아보기");AppendMenuW(m,MF_STRING|(scene==2?MF_CHECKED:0),12,L"배경 없는 동작 · 분홍 옷 산책");AppendMenuW(m,MF_STRING|(scene==3?MF_CHECKED:0),13,L"배경 없는 동작 · 손짓");AppendMenuW(m,MF_SEPARATOR,0,0);AppendMenuW(m,MF_STRING,5,L"크기: 작게");AppendMenuW(m,MF_STRING,6,L"크기: 보통");AppendMenuW(m,MF_STRING,7,L"크기: 크게");AppendMenuW(m,MF_STRING,8,L"화면 아래로 데려오기");AppendMenuW(m,MF_SEPARATOR,0,0);AppendMenuW(m,MF_STRING,9,L"종료");POINT p;GetCursorPos(&p);SetForegroundWindow(win);int cmd=TrackPopupMenu(m,TPM_RETURNCMD|TPM_RIGHTBUTTON,p.x,p.y,0,win,0);DestroyMenu(m);if(cmd>=10&&cmd<=13){scene=cmd-10;sceneStart=GetTickCount64();sleeping=FALSE;mood=0;roam=scene?FALSE:TRUE;}if(cmd==1){scene=0;sleeping=FALSE;mood=2;moodUntil=tick+130;}if(cmd==2){scene=0;sleeping=!sleeping;mood=0;}if(cmd==3)roam=!roam;if(cmd==4){top=!top;clamp();}if(cmd>=5&&cmd<=7){sz=cmd==5?150:cmd==6?210:280;clamp();}if(cmd==8){RECT a;SystemParametersInfoW(SPI_GETWORKAREA,0,&a,0);SetWindowPos(win,0,a.right-sz-40,a.bottom-sz*366/320,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);}if(cmd==9)DestroyWindow(win);InvalidateRect(win,0,FALSE);PostMessageW(win,WM_NULL,0,0);}
static LRESULT CALLBACK proc(HWND h,UINT msg,WPARAM w,LPARAM l){switch(msg){case WM_PAINT:{PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);paint(dc);EndPaint(h,&ps);return 0;}case WM_ERASEBKGND:return 1;case WM_TIMER:tick++;if(mood&&tick>moodUntil)mood=0;if(roam&&!sleeping&&!drag&&!mood&&tick%2==0){RECT r,a=area();GetWindowRect(h,&r);if(++travel%250==0)dir=-dir;int x=r.left+dir;if(x<a.left||x+sz>a.right){dir=-dir;x=r.left+dir;}SetWindowPos(h,0,x,r.top,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);}InvalidateRect(h,0,FALSE);return 0;
case WM_LBUTTONDOWN:drag=TRUE;GetCursorPos(&anchor);{RECT r;GetWindowRect(h,&r);origin.x=r.left;origin.y=r.top;}SetCapture(h);return 0;
case WM_MOUSEMOVE:if(drag){POINT p;GetCursorPos(&p);SetWindowPos(h,0,origin.x+p.x-anchor.x,origin.y+p.y-anchor.y,0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);}return 0;
case WM_LBUTTONUP:if(drag){POINT p;GetCursorPos(&p);drag=FALSE;ReleaseCapture();clamp();if(abs(p.x-anchor.x)+abs(p.y-anchor.y)<6){sleeping=FALSE;mood=1;moodUntil=tick+90;}}return 0;
case WM_CAPTURECHANGED:drag=FALSE;return 0;case WM_RBUTTONUP:menu();return 0;case TRAY:if(l==WM_RBUTTONUP)menu();else if(l==WM_LBUTTONDBLCLK){ShowWindow(h,SW_SHOWNOACTIVATE);clamp();}return 0;case WM_DISPLAYCHANGE:case WM_SETTINGCHANGE:clamp();return 0;case WM_DESTROY:KillTimer(h,1);Shell_NotifyIconW(NIM_DELETE,&tray);PostQuitMessage(0);return 0;}return DefWindowProcW(h,msg,w,l);}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE prev,LPWSTR cmd,int show){(void)prev;(void)cmd;(void)show;HANDLE mutex=CreateMutexW(0,TRUE,L"Local\\ChiikawaDesktopPet_v1");if(GetLastError()==ERROR_ALREADY_EXISTS){MessageBoxW(0,L"치이카와 펫이 이미 실행 중이에요. 작업 표시줄의 숨겨진 아이콘을 확인해주세요.",L"치이카와",MB_OK);CloseHandle(mutex);return 0;}SetProcessDPIAware();WNDCLASSW wc={0};wc.lpfnWndProc=proc;wc.hInstance=inst;wc.lpszClassName=L"ChiikawaPetWindow";wc.hCursor=LoadCursor(0,IDC_HAND);wc.hIcon=LoadIconW(inst,MAKEINTRESOURCEW(101));RegisterClassW(&wc);RECT a;SystemParametersInfoW(SPI_GETWORKAREA,0,&a,0);win=CreateWindowExW(WS_EX_LAYERED|WS_EX_TOOLWINDOW|WS_EX_TOPMOST|WS_EX_NOACTIVATE,wc.lpszClassName,L"치이카와 데스크톱 펫",WS_POPUP,a.right-sz-40,a.bottom-sz*366/320,sz,sz*366/320,0,0,inst,0);if(!win){CloseHandle(mutex);return 1;}tray.cbSize=sizeof(tray);tray.hWnd=win;tray.uID=1;tray.uFlags=NIF_ICON|NIF_MESSAGE|NIF_TIP;tray.uCallbackMessage=TRAY;tray.hIcon=wc.hIcon;lstrcpyW(tray.szTip,L"치이카와 · 우클릭 메뉴 / 더블클릭 복귀");Shell_NotifyIconW(NIM_ADD,&tray);ShowWindow(win,SW_SHOWNOACTIVATE);sceneStart=GetTickCount64()-2400;SetTimer(win,1,33,0);MSG m;while(GetMessageW(&m,0,0,0)>0){TranslateMessage(&m);DispatchMessageW(&m);}CloseHandle(mutex);return 0;}
