@echo off
cd /d "%~dp0"
where gcc >nul 2>nul
if errorlevel 1 (
  echo MinGW-w64 gcc is required on PATH.
  pause
  exit /b 1
)
windres pet.rc -O coff -o pet.res
if errorlevel 1 exit /b 1
gcc pet.c pet.res -o ..\ChiikawaPet.exe -O2 -Wall -Wextra -municode -mwindows -static -lmsimg32 -lgdi32 -luser32 -lshell32 -lm -Wl,--nxcompat,--dynamicbase
if errorlevel 1 exit /b 1
echo Built ..\ChiikawaPet.exe
pause
