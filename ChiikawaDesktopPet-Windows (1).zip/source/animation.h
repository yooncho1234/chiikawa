#ifndef PET_ANIMATION_H
#define PET_ANIMATION_H
/* Resource identifiers: 202 sleep, 203 apple, 210..217 animation atlas. */
static int pet_frame(unsigned t,int mood,int asleep,int walking,int dragging){
 if(asleep)return 202;
 if(mood==2)return 203;
 if(mood==1)return 216+(t/6)%2;
 /* A 132 ms blink every 4.8 seconds, including while strolling. */
 if(t%145>=141)return 211;
 if(walking&&!dragging)return 212+(t/8)%4;
 return 210;
}
#endif
